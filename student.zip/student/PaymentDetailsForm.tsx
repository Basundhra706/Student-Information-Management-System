import React, { useState, useEffect } from 'react';

interface PaymentFormData {
  totalAmount: string;
  firstInstallment: string;
  secondInstallment: string;
  thirdInstallment: string;
  firstInstallmentDate: string;
  secondInstallmentDate: string;
  thirdInstallmentDate: string;
}

interface Props {
  handleFinalSubmit: () => void;
  setData: (data: PaymentFormData) => void;
}

const PaymentDetailsForm: React.FC<Props> = ({ handleFinalSubmit, setData }) => {
  const [formData, setFormData] = useState<PaymentFormData>({
    totalAmount: '',
    firstInstallment: '',
    secondInstallment: '',
    thirdInstallment: '',
    firstInstallmentDate: '',
    secondInstallmentDate: '',
    thirdInstallmentDate: '',
  });

  const [errorMessage, setErrorMessage] = useState<string>('');

  useEffect(() => {
    setData(formData);
  }, [formData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    // Check if all fields are filled
    if (
      !formData.totalAmount ||
      !formData.firstInstallment ||
      !formData.secondInstallment ||
      !formData.thirdInstallment ||
      !formData.firstInstallmentDate ||
      !formData.secondInstallmentDate ||
      !formData.thirdInstallmentDate
    ) {
      setErrorMessage('Please fill all fields');
      return;
    }
    // Proceed with form submission
    handleFinalSubmit();
  };

  return (
    <div className="p-4">
      <form className="space-y-6">
        {/* Total Amount */}
        <div className="flex flex-col">
          <label className="text-sm font-semibold mb-1">Total Amount</label>
          <input
            type="number"
            name="totalAmount"
            value={formData.totalAmount}
            onChange={handleChange}
            className="max-w-[35%] p-2 border text-sm border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            placeholder="Enter total amount"
          />
        </div>

        {/* Installment Fields */}
        <div className="flex w-full">
          {/* First Installment */}
          <div className="flex flex-col w-full">
            <label className="text-sm font-semibold mb-1">First Installment</label>
            <input
              type="number"
              name="firstInstallment"
              value={formData.firstInstallment}
              onChange={handleChange}
              className="max-w-[70%] p-2 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              placeholder="Enter first installment amount"
            />
          </div>

          {/* First Installment Date */}
          <div className="flex flex-col w-full">
            <label className="text-sm font-semibold mb-1">First Installment Date</label>
            <input
              type="date"
              name="firstInstallmentDate"
              value={formData.firstInstallmentDate}
              onChange={handleChange}
              className="max-w-[70%] p-2 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            />
          </div>
        </div>

        <div className="flex w-full">
          {/* Second Installment */}
          <div className="flex flex-col w-full">
            <label className="text-sm font-semibold mb-1">Second Installment</label>
            <input
              type="number"
              name="secondInstallment"
              value={formData.secondInstallment}
              onChange={handleChange}
              className="max-w-[70%] p-2 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              placeholder="Enter second installment amount"
            />
          </div>

          {/* Second Installment Date */}
          <div className="flex flex-col w-full">
            <label className="text-sm font-semibold mb-1">Second Installment Date</label>
            <input
              type="date"
              name="secondInstallmentDate"
              value={formData.secondInstallmentDate}
              onChange={handleChange}
              className="max-w-[70%] p-2 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            />
          </div>
        </div>

        <div className="flex w-full">
          {/* Third Installment */}
          <div className="flex flex-col w-full">
            <label className="text-sm font-semibold mb-1">Third Installment</label>
            <input
              type="number"
              name="thirdInstallment"
              value={formData.thirdInstallment}
              onChange={handleChange}
              className="max-w-[70%] p-2 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              placeholder="Enter third installment amount"
            />
          </div>

          {/* Third Installment Date */}
          <div className="flex flex-col w-full">
            <label className="text-sm font-semibold mb-1">Third Installment Date</label>
            <input
              type="date"
              name="thirdInstallmentDate"
              value={formData.thirdInstallmentDate}
              onChange={handleChange}
              className="max-w-[70%] p-2 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            />
          </div>
        </div>

        {/* Error Message */}
        {errorMessage && (
          <div className="text-red-600 text-sm mt-2">
            {errorMessage}
          </div>
        )}

        <div className="flex justify-end mt-6">
          <button
            type="button"
            onClick={handleSubmit}
            className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium px-6 py-2 rounded-xl transition-all shadow-md hover:shadow-lg"
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default PaymentDetailsForm;
