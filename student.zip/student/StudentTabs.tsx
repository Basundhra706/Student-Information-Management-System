import * as React from 'react';
import { useTheme } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import BasicDetailsForm from './BasicDetailsForm';
import AcademicDetailsForm from './AcademicDetailsForm';
import CourseDetailsForm from './CourseDetailsForm';
import PaymentDetailsForm from './PaymentDetailsForm';

interface TabPanelProps {
  children?: React.ReactNode;
  dir?: string;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`full-width-tabpanel-${index}`}
      aria-labelledby={`full-width-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography component="div">{children}</Typography>
        </Box>
      )}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `full-width-tab-${index}`,
    'aria-controls': `full-width-tabpanel-${index}`,
  };
}

export default function StudentTabs() {
  const theme = useTheme();
  const [value, setValue] = React.useState(0);

  const [basicData, setBasicData] = React.useState({
    name: '',
    email: '',
    contactNo: '',
    altContactNo: '',
    dob: '',
    currentAddress: '',
    permanentAddress: '',
    location: '',
    role: '',
  });

  const [academicData, setAcademicData] = React.useState({
    graduationField: '',
    passoutYear: '',
    working: '',
  });

  const [courseData, setCourseData] = React.useState({
    courseName: '',
    duration: '',
    courseType: '',
    location: '',
    startDate: '',
    endDate: '',
    totalAmount: '',
    firstInstallment: '',
    secondInstallment: '',
    thirdInstallment: '',
  });

  const [paymentData, setPaymentData] = React.useState({
    paymentMethod: '',
    transactionId: '',
  });

  const [submissionSuccess, setSubmissionSuccess] = React.useState('');
  const [submissionError, setSubmissionError] = React.useState('');

  const goToNextTab = () => {
    setValue((prev) => Math.min(prev + 1, 3));
  };

  const handleFinalSubmit = async () => {
    const fullData = {
      ...basicData,
      ...academicData,
      ...courseData,
      ...paymentData,
    };

    try {
      const response = await fetch('http://localhost:9090/students/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fullData),
      });

      if (!response.ok) throw new Error('Submission failed.');
      const result = await response.json();
      setSubmissionSuccess(result.message || 'All data submitted successfully!');
      setSubmissionError('');

      // ✅ Go to first tab
      setValue(0);

      // ✅ Optional: clear form fields
      setBasicData({
        name: '',
        email: '',
        contactNo: '',
        altContactNo: '',
        dob: '',
        currentAddress: '',
        permanentAddress: '',
        location: '',
        role: '',
      });

      setAcademicData({
        graduationField: '',
        passoutYear: '',
        working: '',
      });

      setCourseData({
        courseName: '',
        duration: '',
        courseType: '',
        location: '',
        startDate: '',
        endDate: '',
        totalAmount: '',
        firstInstallment: '',
        secondInstallment: '',
        thirdInstallment: '',
      });

      setPaymentData({
        paymentMethod: '',
        transactionId: '',
      });

    } catch (err: any) {
      setSubmissionError(err.message || 'An error occurred!');
      setSubmissionSuccess('');
    }
  };

  return (
    <Box sx={{ bgcolor: 'background.paper', width: '100%' }}>
      <AppBar position="static">
        <Tabs
          value={value}
          onChange={(e, newValue) => setValue(newValue)}
          indicatorColor="secondary"
          textColor="inherit"
          variant="fullWidth"
        >
          <Tab label="Basic Details" {...a11yProps(0)} />
          <Tab label="Academic Details" {...a11yProps(1)} />
          <Tab label="Course Details" {...a11yProps(2)} />
          <Tab label="Payment Details" {...a11yProps(3)} />
        </Tabs>
      </AppBar>

      <TabPanel value={value} index={0} dir={theme.direction}>
        <BasicDetailsForm goToNextTab={goToNextTab} setData={setBasicData} />
      </TabPanel>
      <TabPanel value={value} index={1} dir={theme.direction}>
        <AcademicDetailsForm goToNextTab={goToNextTab} setData={setAcademicData} />
      </TabPanel>
      <TabPanel value={value} index={2} dir={theme.direction}>
        <CourseDetailsForm goToNextTab={goToNextTab} setData={setCourseData} />
      </TabPanel>
      <TabPanel value={value} index={3} dir={theme.direction}>
        <PaymentDetailsForm handleFinalSubmit={handleFinalSubmit} setData={setPaymentData} />
        {submissionSuccess && <p className="text-green-600 mt-3">{submissionSuccess}</p>}
        {submissionError && <p className="text-red-600 mt-3">{submissionError}</p>}
      </TabPanel>
    </Box>
  );
}
