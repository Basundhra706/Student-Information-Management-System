import React, { useState } from 'react';

interface FormData {
  name: string;
  email: string;
  contactNo: string;
  altContactNo: string;
  dob: string;
  currentAddress: string;
  permanentAddress: string;
  role: string;
}

interface Props {
  goToNextTab: () => void;
  setData: (data: FormData) => void;
}

const BasicDetailsForm: React.FC<Props> = ({ goToNextTab, setData }) => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    contactNo: '',
    altContactNo: '',
    dob: '',
    currentAddress: '',
    permanentAddress: '',
    role: '',
  });

  const [errorMessage, setErrorMessage] = useState<string>('');

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleNext = () => {
    // Validate that all fields are filled
    if (
      !formData.name ||
      !formData.email ||
      !formData.contactNo ||
      !formData.dob ||
      !formData.currentAddress ||
      !formData.permanentAddress ||
      !formData.role
    ) {
      setErrorMessage('Please fill in all fields.');
      return;
    }

    // Clear the error message if all fields are filled
    setErrorMessage('');

    // Set the form data and go to the next tab
    setData(formData);
    goToNextTab();
  };

  return (
    <div className="p-6 bg-white rounded-xl shadow-lg">
      <form className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {/* Full Name */}
        <div>
          <label className="block font-bold text-sm text-gray-800 mb-1">Full Name</label>
          <input
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="min-w-[70%] text-sm p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            placeholder="Enter your full name"
          />
        </div>

        {/* Email */}
        <div>
          <label className="block font-bold text-sm text-gray-800 mb-1">Email</label>
          <input
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            className="min-w-[70%] text-sm p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            placeholder="example@mail.com"
          />
        </div>

        {/* Contact No */}
        <div>
          <label className="block font-bold text-sm text-gray-800 mb-1">Contact Number</label>
          <input
            name="contactNo"
            value={formData.contactNo}
            onChange={handleChange}
            className="min-w-[70%] text-sm p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            placeholder="Primary contact"
          />
        </div>

        {/* Alternate Contact No */}
        <div>
          <label className="block font-bold text-sm text-gray-800 mb-1">Alternate Contact</label>
          <input
            name="altContactNo"
            value={formData.altContactNo}
            onChange={handleChange}
            className="min-w-[70%] text-sm p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            placeholder="Alternate number (optional)"
          />
        </div>

        {/* Date of Birth */}
        <div>
          <label className="block font-bold text-sm text-gray-800 mb-1">Date of Birth</label>
          <input
            name="dob"
            type="date"
            value={formData.dob}
            onChange={handleChange}
            className="min-w-[70%] text-sm p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
          />
        </div>

        {/* Role */}
        <div>
          <label className="block font-bold text-sm text-gray-800 mb-1">Role</label>
          <select
            name="role"
            value={formData.role}
            onChange={handleChange}
            className="min-w-[70%] text-sm p-2 border border-gray-300 rounded-md shadow-sm bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
          >
            <option value="">Select Role</option>
            <option value="student">Student</option>
            <option value="employee">Employee</option>
          </select>
        </div>

        {/* Current Address */}
        <div className="md:col-span-2">
          <label className="block font-bold text-sm text-gray-800 mb-1">Current Address</label>
          <textarea
            name="currentAddress"
            value={formData.currentAddress}
            onChange={handleChange}
            rows={3}
            className="min-w-[70%] text-sm p-1 h-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            placeholder="Enter your current address"
          />
        </div>

        {/* Permanent Address */}
        <div className="md:col-span-2">
          <label className="block font-bold text-sm text-gray-800 mb-1">Permanent Address</label>
          <textarea
            name="permanentAddress"
            value={formData.permanentAddress}
            onChange={handleChange}
            rows={3}
            className="min-w-[70%] text-sm p-1 h-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            placeholder="Enter your permanent address"
          />
        </div>
      </form>

      {/* Error Message */}
      {errorMessage && (
        <div className="text-red-600 text-sm mt-2">
          {errorMessage}
        </div>
      )}

      <button
        type="button"
        onClick={handleNext}
        className="absolute right-20 bottom-20 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium px-6 py-2 rounded-xl transition-all shadow-md hover:shadow-lg mt-4 mb-4"
      >
        Next
      </button>
    </div>
  );
};

export default BasicDetailsForm;
