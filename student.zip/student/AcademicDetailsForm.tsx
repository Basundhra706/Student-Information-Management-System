
import React, { useState } from 'react';

interface AcademicFormData {
  graduated: boolean | null;
  graduationField: string;
  passoutYear: string;
  working: string | null;  // This field will store work details if provided, or null otherwise
}

interface Props {
  goToNextTab: () => void;
  setData: (data: AcademicFormData) => void;
}

const AcademicDetailsForm: React.FC<Props> = ({ goToNextTab, setData }) => {
  // Form data for graduation details.
  const [formData, setFormData] = useState<AcademicFormData>({
    graduated: null,
    graduationField: '',
    passoutYear: '',
    working: null,
  });

  // Local state for controlling the radio button (currently working) and capturing text for work details.
  const [isWorking, setIsWorking] = useState<null | boolean>(null);
  const [workDetails, setWorkDetails] = useState<string>('');

  // Handle changes for graduationField and passoutYear.
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Handle Graduated radio buttons.
  const handleGraduatedChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value === 'yes';
    setFormData(prev => ({ ...prev, graduated: value }));
  };

  // Handle Currently Working radio buttons.
  const handleWorkingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value === 'yes';
    setIsWorking(value);
    if (!value) {
      // When "No" is selected, clear any work details.
      setWorkDetails('');
    }
  };

  // Handle changes in the work details textarea.
  const handleWorkDetailsChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setWorkDetails(e.target.value);
  };

  // On Next, combine the states: if the user is working (yes) then the "working" field will be set to workDetails text,
  // otherwise it will be null.
  const handleNext = () => {
    const dataToSend: AcademicFormData = {
      ...formData,
      working: isWorking ? workDetails : null,
    };
    setData(dataToSend);
    goToNextTab();
  };

  return (
    <div className="p-6 bg-white rounded-xl shadow-lg">
      <h2 className="text-lg font-bold mb-6 text-gray-800">Academic Details</h2>

      <form className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Graduated */}
        <div className="md:col-span-2">
          <label className="block text-sm font-bold text-gray-800 mb-2">
            Graduated
          </label>
          <div className="flex gap-6">
            {['yes', 'no'].map(option => (
              <label key={option} className="flex items-center gap-2 text-sm ">
                <input
                  type="radio"
                  name="graduated"
                  value={option}
                  checked={formData.graduated === (option === 'yes')}
                  onChange={handleGraduatedChange}
                  className="accent-indigo-600"
                />
                <span className="capitalize text-gray-700">{option}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Graduation Fields */}
        {formData.graduated && (
          <>
            <div>
              <label className="block text-sm font-semibold text-gray-800 mb-2">
                Graduation Field
              </label>
              <input
                type="text"
                name="graduationField"
                value={formData.graduationField}
                onChange={handleChange}
                className="w-full p-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
                placeholder="e.g. B.Tech, B.Sc"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-800 mb-2">
                Passout Year
              </label>
              <input
                type="date"
                name="passoutYear"
                value={formData.passoutYear}
                onChange={handleChange}
                className="w-full p-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
              />
            </div>
          </>
        )}

        {/* Currently Working */}
        <div className="md:col-span-2">
          <label className="block text-sm font-bold text-gray-800 mb-2">
            Currently Working
          </label>
          <div className="flex gap-6">
            {['yes', 'no'].map(option => (
              <label key={option} className="flex items-center gap-2 text-sm">
                <input
                  type="radio"
                  name="workingRadio"
                  value={option}
                  checked={isWorking === (option === 'yes')}
                  onChange={handleWorkingChange}
                  className="accent-indigo-600"
                />
                <span className="capitalize text-gray-700">{option}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Work Details */}
        {isWorking && (
          <div className="md:col-span-2">
            <label className="block text-sm font-semibold text-gray-800 mb-2">
              Work Details
            </label>
            <textarea
              name="workDetails"
              value={workDetails}
              onChange={handleWorkDetailsChange}
              rows={3}
              className="w-full p-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
              placeholder="Enter details about your work experience"
            />
          </div>
        )}
      </form>

      <div className="flex justify-end mt-8">
        <button
          type="button"
          onClick={handleNext}
          className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium px-6 py-2 rounded-xl transition-all shadow-md hover:shadow-lg"
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default AcademicDetailsForm;
