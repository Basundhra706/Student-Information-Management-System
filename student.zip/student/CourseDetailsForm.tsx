import React, { useState } from 'react';

interface CourseFormData {
  courseName: string;
  duration: string;
  courseType: string;
  location: string;
  startDate: string;
  endDate: string;
}

interface Props {
  goToNextTab: () => void;
  setData: (data: CourseFormData) => void;
}

const CourseDetailsForm: React.FC<Props> = ({ goToNextTab, setData }) => {
  const [formData, setFormData] = useState<CourseFormData>({
    courseName: '',
    duration: '',
    courseType: '',
    location: '',
    startDate: '',
    endDate: '',
  });

  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};
    Object.keys(formData).forEach(field => {
      if (!formData[field as keyof CourseFormData]) {
        newErrors[field] = `${field} is required`;
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateForm()) {
      setData(formData);
      goToNextTab();
    }
  };

  return (
    <div className="p-4">
      <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {[
          { label: 'Course Name', name: 'courseName', type: 'text' },
          { label: 'Duration', name: 'duration', type: 'text' },
          { label: 'Course Type', name: 'courseType', type: 'text' },
          { label: 'Location', name: 'location', type: 'text' },
          { label: 'Start Date', name: 'startDate', type: 'date' },
          { label: 'End Date', name: 'endDate', type: 'date' }
        ].map(field => (
          <div key={field.name} className="flex flex-col">
            <label className="text-sm font-bold mb-1">{field.label}</label>
            <input
              type={field.type}
              name={field.name}
              value={formData[field.name as keyof CourseFormData]}
              onChange={handleChange}
              className={`max-w-[70%] text-sm p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition ${
                errors[field.name] ? 'border-red-500' : ''
              }`}
              placeholder={field.label}
            />
            {errors[field.name] && (
              <span className="text-red-500 text-sm">{errors[field.name]}</span>
            )}
          </div>
        ))}
      </form>

      <div className="flex justify-end mt-4">
        <button
          type="button"
          onClick={handleNext}
          className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium px-6 py-2 rounded-xl transition-all shadow-md hover:shadow-lg"
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default CourseDetailsForm;
